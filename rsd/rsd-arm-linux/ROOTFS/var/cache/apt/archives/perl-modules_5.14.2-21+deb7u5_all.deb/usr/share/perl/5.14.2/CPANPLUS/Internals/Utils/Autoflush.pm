package CPANPLUS::Internals::Utils::Autoflush;

BEGIN { $|++ };

1;
